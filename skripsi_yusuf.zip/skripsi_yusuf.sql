-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 15, 2022 at 04:19 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `skripsi_yusuf`
--

-- --------------------------------------------------------

--
-- Table structure for table `deal_stok`
--

CREATE TABLE `deal_stok` (
  `id` int(11) NOT NULL,
  `tgl_po` varchar(128) NOT NULL,
  `brand` varchar(128) NOT NULL,
  `tipe_mobil` varchar(128) NOT NULL,
  `plat_mobil` varchar(128) NOT NULL,
  `tahun` year(4) NOT NULL,
  `warna` varchar(128) NOT NULL,
  `appraiser` varchar(128) NOT NULL,
  `is_booking` int(11) NOT NULL,
  `is_sold` int(11) NOT NULL,
  `sales` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `deal_stok`
--

INSERT INTO `deal_stok` (`id`, `tgl_po`, `brand`, `tipe_mobil`, `plat_mobil`, `tahun`, `warna`, `appraiser`, `is_booking`, `is_sold`, `sales`) VALUES
(1, '2020-05-05', 'Toyota', 'Kijang', 'AA1234DHD', 2015, 'Silver', 'Abdul', 1, 0, 'Makise Kurisu');

-- --------------------------------------------------------

--
-- Table structure for table `tb_roleid`
--

CREATE TABLE `tb_roleid` (
  `role_id` int(11) NOT NULL,
  `nama_role` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_roleid`
--

INSERT INTO `tb_roleid` (`role_id`, `nama_role`) VALUES
(1, 'Administrator'),
(2, 'TNT'),
(3, 'Sales');

-- --------------------------------------------------------

--
-- Table structure for table `tb_user`
--

CREATE TABLE `tb_user` (
  `id` int(11) NOT NULL,
  `no_pegawai` int(16) NOT NULL,
  `name` varchar(128) NOT NULL,
  `role_id` int(11) NOT NULL,
  `region` varchar(128) NOT NULL,
  `no_telp` varchar(14) NOT NULL,
  `password` varchar(256) NOT NULL,
  `date_created` int(11) NOT NULL,
  `last_login` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_user`
--

INSERT INTO `tb_user` (`id`, `no_pegawai`, `name`, `role_id`, `region`, `no_telp`, `password`, `date_created`, `last_login`) VALUES
(5, 1, 'Admin Yusuf', 1, '', '', '$2y$10$Kpt47OMyvkgDD6PQnVH.Lebx817KPad.YbykNSmyCAvpt8eh2P.SO', 0, 0),
(6, 12345678, 'Kristovel A.S.', 2, 'Bogor', '55555', '$2y$10$ZtS/ZYrDS/74/Q3NhYsZLeUIfmBxrTzMV2NOSRBiz4vFjwIlEhZkG', 1654975026, 0),
(8, 11223344, 'Kristovel', 3, 'Kalimalang', '838123', '$2y$10$S.bz2wgwmZ/nJBgeprvyfedOx7y9OIruCjeI/Yo9v7hqYA3rYFzeS', 1654976040, 0),
(11, 2020, 'Christina', 2, 'Kalimalang', '2147483647', '$2y$10$SIhWw8jGNiogfGgDbv6ZE.rvxFumWuVvI6is44XmWCbAz5HZrEmFi', 1655481612, 0),
(12, 55555, 'Makise Kurisu', 3, 'Kalimalang', '081285415249', '$2y$10$oUdTWNuip/dyLKglDutfBeRGXJ7wHK/.vdZ.ruGaSw2CjweGWrX9S', 1655482256, 0),
(13, 1212, 'Kura Kura', 2, 'Kalimalang', '081285415249', '$2y$10$mSAlYW6sVMCj7tfxuRWphu47pUSfWMl3rO3DFnJXNmEjDJlxJIiIW', 1655482497, 0),
(14, 44444, 'People 4', 2, 'Kalimalang', '081284529756', '$2y$10$agDuCmpkiIoC4xz7CekdFusiFdRWwGuNBfSzF8bgyqi5rQGK2e3Oe', 1655482701, 0),
(15, 88888, 'Kurisu', 3, 'Kalimalang', '081284529756', '$2y$10$LY7ftNaaqmW/3koE4Zita.j8nvn30omcjjHG52KbXzdo.sxc4COt6', 1655482812, 0);

-- --------------------------------------------------------

--
-- Table structure for table `update_po`
--

CREATE TABLE `update_po` (
  `id` int(11) NOT NULL,
  `kode_po` varchar(20) NOT NULL,
  `tgl_po` varchar(128) NOT NULL,
  `brand` varchar(128) NOT NULL,
  `tipe_mobil` varchar(128) NOT NULL,
  `plat_mobil` varchar(128) NOT NULL,
  `tahun` year(4) NOT NULL,
  `warna` varchar(128) NOT NULL,
  `appraiser` varchar(128) NOT NULL,
  `is_confirm` int(11) NOT NULL,
  `sales` varchar(128) NOT NULL,
  `is_booking` int(11) NOT NULL,
  `is_sold` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `update_po`
--

INSERT INTO `update_po` (`id`, `kode_po`, `tgl_po`, `brand`, `tipe_mobil`, `plat_mobil`, `tahun`, `warna`, `appraiser`, `is_confirm`, `sales`, `is_booking`, `is_sold`) VALUES
(1, 'PO1472272210', '2020-05-05', 'Toyota', 'Kijang', 'AA1234DHD', 2015, 'Silver', 'Abdul', 1, 'Makise Kurisu', 1, 0),
(26, '', '2020-07-15', 'Honda', 'Civic', 'BK567UAH', 2017, 'HItam', 'Neko', 0, '', 0, 0),
(27, '', '2021-07-12', 'Toyota', 'Kijang', 'BK434UHU', 2020, 'Hitam', 'Santoso', 0, '', 0, 0),
(28, '', '2021-06-06', 'Honda', 'Civic', 'B123UNJ', 2021, 'Silver', 'Setia Budi', 0, '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user_access_menu`
--

CREATE TABLE `user_access_menu` (
  `id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_access_menu`
--

INSERT INTO `user_access_menu` (`id`, `role_id`, `menu_id`) VALUES
(1, 1, 1),
(4, 2, 2),
(5, 3, 3),
(6, 1, 4),
(7, 1, 6);

-- --------------------------------------------------------

--
-- Table structure for table `user_menu`
--

CREATE TABLE `user_menu` (
  `id` int(11) NOT NULL,
  `menu` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_menu`
--

INSERT INTO `user_menu` (`id`, `menu`) VALUES
(1, 'Admin'),
(2, 'TNT'),
(3, 'Sales'),
(6, 'Profile');

-- --------------------------------------------------------

--
-- Table structure for table `user_submenu`
--

CREATE TABLE `user_submenu` (
  `id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `title` varchar(128) NOT NULL,
  `url` varchar(128) NOT NULL,
  `icon` varchar(128) NOT NULL,
  `is_active` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_submenu`
--

INSERT INTO `user_submenu` (`id`, `menu_id`, `title`, `url`, `icon`, `is_active`) VALUES
(1, 1, 'Dashboard', 'admin', 'fas fa-fw fa-tachometer-alt', 1),
(5, 4, 'Menu Management', 'menu', 'fas fa-fw fa-folder', 0),
(6, 4, 'Sub Menu Management', 'menu/submenu', 'fas fa-fw fa-folder-open', 0),
(9, 2, 'Update PO', 'tnt', 'fas fa-fw fa-solid fa-cart-arrow-down', 1),
(10, 3, 'View Stock', 'sales', 'fas fa-fw fa-box', 1),
(11, 3, 'View Stock Coming Soon', 'sales/stok_comingSoon', 'fas fa-fw fa-solid fa-box-archive', 1),
(12, 3, 'Profile', 'sales/profile', 'fas fa-fw fa-solid fa-user', 1),
(13, 2, 'Profile', 'tnt/profile', 'fas fa-fw fa-user', 1),
(14, 6, 'Admin Profile', 'admin/profile', 'fas fa-fw fa-user', 1),
(15, 6, 'User Profile', 'admin/data_profile', 'fas fa-fw fa-user-pen', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `deal_stok`
--
ALTER TABLE `deal_stok`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_roleid`
--
ALTER TABLE `tb_roleid`
  ADD PRIMARY KEY (`role_id`);

--
-- Indexes for table `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `update_po`
--
ALTER TABLE `update_po`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_access_menu`
--
ALTER TABLE `user_access_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_menu`
--
ALTER TABLE `user_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_submenu`
--
ALTER TABLE `user_submenu`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_roleid`
--
ALTER TABLE `tb_roleid`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `update_po`
--
ALTER TABLE `update_po`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `user_access_menu`
--
ALTER TABLE `user_access_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `user_menu`
--
ALTER TABLE `user_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `user_submenu`
--
ALTER TABLE `user_submenu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
